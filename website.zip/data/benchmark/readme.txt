xxx_FD.txt is the data with injected FDs
xxx_graph.txt is the ground-truth graph
the ground-truth is identical to the ground-truth of corresponding dataset from Bayesian Network Repository (Scutari 2012) 